package first;

public interface A
{
    void method();

}
