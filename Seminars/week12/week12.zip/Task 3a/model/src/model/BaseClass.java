package model;

public class BaseClass {
    public void firstMethod()
    {
        System.out.println("First method.");
        secondMethod();
    }
    
    public void secondMethod()
    {
        System.out.println("Second method.");
    }

}
