package test;

import model.BaseClass;
import model.DerivedCLass;

public class Test
{
    public static void main(String[] args)
    {
        BaseClass baseClass = new DerivedCLass();
        baseClass.print();
    }
}
