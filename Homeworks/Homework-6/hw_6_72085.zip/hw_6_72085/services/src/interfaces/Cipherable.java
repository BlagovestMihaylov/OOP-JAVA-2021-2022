package interfaces;

public interface Cipherable
{
    char[] getSecretChars(int seed);
}
