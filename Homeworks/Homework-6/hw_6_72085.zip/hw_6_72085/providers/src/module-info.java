module providers {
    requires services;
    exports generator;
}