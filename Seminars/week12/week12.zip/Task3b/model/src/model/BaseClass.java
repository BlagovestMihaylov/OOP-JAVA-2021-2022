package model;

public abstract class BaseClass
{

    public BaseClass()
    {
        print();
    }

    public abstract void print();

}
