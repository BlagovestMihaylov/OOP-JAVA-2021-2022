package test;

import model.BaseClass;
import model.DerivedClass;

public class Test
{
    public static void main(String[] args)
    {
        DerivedClass clazz = new DerivedClass();
        clazz.method();
    }
}
