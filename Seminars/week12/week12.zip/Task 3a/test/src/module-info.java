module test {
    requires model;
}