module Task3c {
    exports model;
}