package model;

public class DerivedCLass extends BaseClass
{

    private  int value = 1;
    @Override
    public void print()
    {
        System.out.println(value);
    }
}
