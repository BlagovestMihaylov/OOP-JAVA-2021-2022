package test;

import third.D;

public class Test
{
    public static void main(String[] args)
    {
        D d = new D();
        d.getA().method();
    }
}
