package third;

import first.A;
import second.B;

public class D extends B
{


}
