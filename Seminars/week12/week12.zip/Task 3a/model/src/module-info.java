module model {
    exports model;
}