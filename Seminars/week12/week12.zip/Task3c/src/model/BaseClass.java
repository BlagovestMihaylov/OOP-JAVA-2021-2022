package model;

public class BaseClass
{
}
