package model;

public class DerivedClass extends BaseClass{

    @Override
    public void secondMethod()
    {
        System.out.println("Second overridden method.");
    }
}
